
import type { DatosParqueo, Espacio, Estancia } from "./types";

export const TARIFA_SALIDA = 1.00;

// Normalizar placa: quitar espacios y convertir a mayúsculas
export function normalizarPlaca(placa: string): string {
  return placa.trim().toUpperCase();
}

// Generar ID automático
function siguienteId(lista: { id: number }[]): number {
  return lista.length
    ? Math.max(...lista.map(item => item.id)) + 1
    : 1;
}

// ================================
// REGISTRAR ENTRADA
// ================================
export function registrarEntrada(
  datos: DatosParqueo,
  placaIngresada: string
): string {

  const placa = normalizarPlaca(placaIngresada);

  if (!placa) {
    throw new Error("Debe ingresar una placa.");
  }

  const duplicada = datos.estancias.some(
    estancia => estancia.activa && estancia.placa === placa
  );

  if (duplicada) {
    throw new Error("Este vehículo ya se encuentra dentro del parqueo.");
  }

  const espacio = datos.espacios.find(
    espacio => !espacio.ocupado
  );

  if (!espacio) {
    throw new Error("No hay espacios disponibles.");
  }

  const fecha = new Date().toISOString();

  const estancia: Estancia = {
    id: siguienteId(datos.estancias),
    placa,
    espacioId: espacio.id,
    entrada: fecha,
    salida: null,
    activa: true,
    tarifa: 0
  };

  espacio.ocupado = true;
  espacio.placa = placa;

  datos.estancias.push(estancia);

  datos.movimientos.push({
    id: siguienteId(datos.movimientos),
    tipo: "entrada",
    placa,
    espacioCodigo: espacio.codigo,
    fecha,
    detalle: `Entrada registrada en ${espacio.codigo}`,
    monto: 0
  });

  return `Entrada registrada. Vehículo ${placa}, espacio ${espacio.codigo}.`;
}

// ================================
// REGISTRAR SALIDA
// ================================
export function registrarSalida(
  datos: DatosParqueo,
  placaIngresada: string
): string {

  const placa = normalizarPlaca(placaIngresada);

  if (!placa) {
    throw new Error("Debe ingresar la placa.");
  }

  const estancia = datos.estancias.find(
    estancia => estancia.activa && estancia.placa === placa
  );

  if (!estancia) {
    throw new Error("No existe una entrada activa para esta placa.");
  }

  const espacio = datos.espacios.find(
    espacio => espacio.id === estancia.espacioId
  );

  if (!espacio || !espacio.ocupado || espacio.placa !== placa) {
    throw new Error("Error de validación del espacio. No se realizó el cobro.");
  }

  const fecha = new Date().toISOString();

  estancia.activa = false;
  estancia.salida = fecha;
  estancia.tarifa = TARIFA_SALIDA;

  espacio.ocupado = false;
  espacio.placa = null;

  datos.recaudacion = Number(
    (datos.recaudacion + TARIFA_SALIDA).toFixed(2)
  );

  datos.movimientos.push({
    id: siguienteId(datos.movimientos),
    tipo: "salida",
    placa,
    espacioCodigo: espacio.codigo,
    fecha,
    detalle: `Salida de ${espacio.codigo}`,
    monto: TARIFA_SALIDA
  });

  return `Salida registrada. ${placa} liberó ${espacio.codigo}. Cobro: $1.00.`;
}

// ================================
// CREAR ESPACIO
// ================================
export function crearEspacio(
  datos: DatosParqueo,
  codigoIngresado: string
): Espacio {

  const codigo = codigoIngresado.trim().toUpperCase();

  if (!codigo) {
    throw new Error("El código del espacio es obligatorio.");
  }

  const existe = datos.espacios.some(
    espacio => espacio.codigo.toUpperCase() === codigo
  );

  if (existe) {
    throw new Error("Ese espacio ya existe.");
  }

  const nuevo: Espacio = {
    id: siguienteId(datos.espacios),
    codigo,
    ocupado: false,
    placa: null
  };

  datos.espacios.push(nuevo);

  return nuevo;
}

// ================================
// EDITAR ESPACIO
// ================================
export function editarEspacio(
  datos: DatosParqueo,
  id: number,
  codigoIngresado: string
): string {

  const codigo = codigoIngresado.trim().toUpperCase();

  if (!codigo) {
    throw new Error("El nuevo código es obligatorio.");
  }

  const espacio = datos.espacios.find(
    espacio => espacio.id === id
  );

  if (!espacio) {
    throw new Error("Espacio no encontrado.");
  }

  const duplicado = datos.espacios.some(
    otro => otro.id !== id && otro.codigo.toUpperCase() === codigo
  );

  if (duplicado) {
    throw new Error("Ya existe otro espacio con ese código.");
  }

  const anterior = espacio.codigo;
  espacio.codigo = codigo;

  return `Espacio ${anterior} actualizado a ${codigo}.`;
}

// ================================
// ELIMINAR ESPACIO
// ================================
export function eliminarEspacio(
  datos: DatosParqueo,
  id: number
): string {

  const espacio = datos.espacios.find(
    espacio => espacio.id === id
  );

  if (!espacio) {
    throw new Error("Espacio no encontrado.");
  }

  if (espacio.ocupado) {
    throw new Error("No se puede eliminar un espacio ocupado.");
  }

  datos.espacios = datos.espacios.filter(
    espacio => espacio.id !== id
  );

  return `Espacio ${espacio.codigo} eliminado correctamente.`;
}
