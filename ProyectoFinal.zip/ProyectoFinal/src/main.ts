
import type { DatosParqueo, Espacio, Movimiento } from "./types";
import {
  registrarEntrada,
  registrarSalida,
  crearEspacio,
  editarEspacio,
  eliminarEspacio,
  normalizarPlaca
} from "./parqueo";

// ============================================
// CONFIGURACIÓN
// ============================================

const STORAGE_KEY = "parqueoexpress_datos_v1";

let datos: DatosParqueo = {
  espacios: [],
  estancias: [],
  movimientos: [],
  recaudacion: 0
};

let editSpaceId: number | null = null;

// ============================================
// ELEMENTOS HTML
// ============================================

const $ = <T extends HTMLElement>(id: string): T => {
  const elemento = document.getElementById(id);

  if (!elemento) {
    throw new Error(`No se encontró el elemento HTML: ${id}`);
  }

  return elemento as T;
};

const entryForm = $("entryForm") as HTMLFormElement;
const exitForm = $("exitForm") as HTMLFormElement;
const spaceForm = $("spaceForm") as HTMLFormElement;

const entryPlate = $("entryPlate") as HTMLInputElement;
const exitPlate = $("exitPlate") as HTMLInputElement;
const spaceCode = $("spaceCode") as HTMLInputElement;

const parkingGrid = $("parkingGrid");
const spacesTableBody = $("spacesTableBody");
const historyTableBody = $("historyTableBody");

const parkingSearch = $("parkingSearch") as HTMLInputElement;
const parkingFilter = $("parkingFilter") as HTMLSelectElement;
const historySearch = $("historySearch") as HTMLInputElement;
const historyFilter = $("historyFilter") as HTMLSelectElement;

const vehiclesCount = $("vehiclesCount");
const totalSpaces = $("totalSpaces");
const freeSpaces = $("freeSpaces");
const occupiedSpaces = $("occupiedSpaces");
const totalRevenue = $("totalRevenue");

const spaceFormTitle = $("spaceFormTitle");
const saveSpaceButton = $("saveSpaceButton");
const cancelEditButton = $("cancelEditButton");
const resetButton = $("resetButton");

// ============================================
// UTILIDADES
// ============================================

function escaparHTML(valor: string): string {
  const entidades: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  };

  return valor.replace(/[&<>"']/g, caracter => entidades[caracter]);
}

function mostrarMensaje(
  mensaje: string,
  tipo: "success" | "error" = "success"
): void {
  let toast = document.getElementById("toast");

  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    document.body.appendChild(toast);
  }

  toast.className = `toast ${tipo}`;
  toast.textContent = mensaje;
  toast.classList.add("visible");

  window.setTimeout(() => {
    toast?.classList.remove("visible");
  }, 3500);
}

function formatearFecha(fecha: string): string {
  return new Date(fecha).toLocaleString("es-SV", {
    dateStyle: "short",
    timeStyle: "short"
  });
}

function guardarDatos(): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(datos));
}

function validarDatos(valor: unknown): valor is DatosParqueo {
  if (!valor || typeof valor !== "object") return false;

  const objeto = valor as DatosParqueo;

  return (
    Array.isArray(objeto.espacios) &&
    Array.isArray(objeto.estancias) &&
    Array.isArray(objeto.movimientos) &&
    typeof objeto.recaudacion === "number"
  );
}

// ============================================
// CARGAR DATOS
// ============================================


async function cargarDatos(): Promise<void> {
  try {
    const local = localStorage.getItem(STORAGE_KEY);

    if (local) {
      try {
        const guardado: unknown = JSON.parse(local);

        if (validarDatos(guardado)) {
          datos = guardado;
          actualizarPantalla();
          return;
        }
      } catch (error) {
        console.warn("Los datos guardados están dañados. Se cargarán los iniciales.", error);
        localStorage.removeItem(STORAGE_KEY);
      }
    }

    const respuesta = await fetch("/data/espacios.json");

    if (!respuesta.ok) {
      throw new Error(
        `No se pudo cargar espacios.json. Estado HTTP: ${respuesta.status}`
      );
    }

    const contenido = await respuesta.text();

    if (!contenido.trim()) {
      throw new Error(
        "espacios.json está llegando vacío. Revisa su ubicación."
      );
    }

    const inicial: unknown = JSON.parse(contenido);

    if (!validarDatos(inicial)) {
      throw new Error("El archivo JSON tiene una estructura incorrecta.");
    }

    datos = inicial;
    guardarDatos();
    actualizarPantalla();

    console.log("ParqueoExpress cargado correctamente.", datos);

  } catch (error) {
    console.error("Error al cargar los datos:", error);
    mostrarMensaje(
      error instanceof Error ? error.message : "Error desconocido al cargar los datos.",
      "error"
    );
  }
}

// ============================================
// PANEL DE CONTROL
// ============================================

function actualizarResumen(): void {
  const ocupados = datos.espacios.filter(e => e.ocupado).length;
  const libres = datos.espacios.length - ocupados;
  const vehiculos = datos.estancias.filter(e => e.activa).length;

  vehiclesCount.textContent = String(vehiculos);
  totalSpaces.textContent = String(datos.espacios.length);
  freeSpaces.textContent = String(libres);
  occupiedSpaces.textContent = String(ocupados);

  totalRevenue.textContent = `$${datos.recaudacion.toFixed(2)}`;
}

// ============================================
// PARQUEOS VISUALES
// ============================================

function renderParking(): void {
  const busqueda = parkingSearch.value.trim().toUpperCase();
  const filtro = parkingFilter.value;

  const espacios = datos.espacios.filter(espacio => {
    const coincideBusqueda =
      espacio.codigo.toUpperCase().includes(busqueda) ||
      (espacio.placa ?? "").toUpperCase().includes(busqueda);

    const coincideFiltro =
      filtro === "todos" ||
      (filtro === "libres" && !espacio.ocupado) ||
      (filtro === "ocupados" && espacio.ocupado);

    return coincideBusqueda && coincideFiltro;
  });

  parkingGrid.innerHTML = espacios.map(espacio => `
    <article class="parking-slot ${espacio.ocupado ? "occupied" : "free"}">
      <div class="slot-icon">${espacio.ocupado ? "🚘" : "🅿️"}</div>
      <strong>${escaparHTML(espacio.codigo)}</strong>
      <span class="slot-status">${espacio.ocupado ? "Ocupado" : "Disponible"}</span>
      ${espacio.placa
        ? `<span class="slot-plate">${escaparHTML(espacio.placa)}</span>`
        : `<span class="slot-plate">Libre</span>`}
    </article>
  `).join("");
}

// ============================================
// ADMINISTRAR ESPACIOS
// ============================================

function renderTablaEspacios(): void {
  spacesTableBody.innerHTML = datos.espacios.map(espacio => `
    <tr>
      <td>${escaparHTML(espacio.codigo)}</td>
      <td>
        <span class="status-pill ${espacio.ocupado ? "occupied" : "free"}">
          ${espacio.ocupado ? "Ocupado" : "Libre"}
        </span>
      </td>
      <td>${escaparHTML(espacio.placa ?? "—")}</td>
      <td>
        <button class="btn-small edit-space" data-id="${espacio.id}">
          Editar
        </button>

        <button class="btn-small danger delete-space"
          data-id="${espacio.id}"
          ${espacio.ocupado ? "disabled" : ""}>
          Eliminar
        </button>
      </td>
    </tr>
  `).join("");
}

function limpiarFormularioEspacio(): void {
  editSpaceId = null;
  spaceForm.reset();

  spaceFormTitle.textContent = "Registrar parqueo";
  saveSpaceButton.textContent = "Guardar espacio";
  cancelEditButton.classList.add("hidden");
}

function iniciarEdicion(espacio: Espacio): void {
  editSpaceId = espacio.id;
  spaceCode.value = espacio.codigo;

  spaceFormTitle.textContent = "Editar parqueo";
  saveSpaceButton.textContent = "Actualizar espacio";
  cancelEditButton.classList.remove("hidden");

  spaceCode.focus();
}

// ============================================
// HISTORIAL DE MOVIMIENTOS
// ============================================

function renderHistorial(): void {
  const busqueda = historySearch.value.trim().toUpperCase();
  const filtro = historyFilter.value;

  const movimientos = [...datos.movimientos]
    .reverse()
    .filter(movimiento => {
      const coincideBusqueda =
        movimiento.placa.toUpperCase().includes(busqueda) ||
        movimiento.espacioCodigo.toUpperCase().includes(busqueda);

      const coincideTipo =
        filtro === "todos" || movimiento.tipo === filtro;

      return coincideBusqueda && coincideTipo;
    });

  if (!movimientos.length) {
    historyTableBody.innerHTML = `
      <tr>
        <td colspan="5">No hay movimientos registrados.</td>
      </tr>
    `;
    return;
  }

  historyTableBody.innerHTML = movimientos.map(movimiento => `
    <tr>
      <td>${formatearFecha(movimiento.fecha)}</td>
      <td>
        <span class="status-pill ${movimiento.tipo}">
          ${movimiento.tipo === "entrada" ? "Entrada" : "Salida"}
        </span>
      </td>
      <td>${escaparHTML(movimiento.placa)}</td>
      <td>${escaparHTML(movimiento.espacioCodigo)}</td>
      <td>$${movimiento.monto.toFixed(2)}</td>
    </tr>
  `).join("");
}

// ============================================
// ACTUALIZAR TODA LA INTERFAZ
// ============================================

function actualizarPantalla(): void {
  actualizarResumen();
  renderParking();
  renderTablaEspacios();
  renderHistorial();
}

// ============================================
// REGISTRAR ENTRADA
// ============================================

entryForm.addEventListener("submit", evento => {
  evento.preventDefault();

  try {
    const mensaje = registrarEntrada(datos, entryPlate.value);

    guardarDatos();
    actualizarPantalla();

    entryForm.reset();
    mostrarMensaje(mensaje, "success");

  } catch (error) {
    mostrarMensaje(
      error instanceof Error ? error.message : "Error al registrar entrada.",
      "error"
    );
  }
});

// ============================================
// REGISTRAR SALIDA
// ============================================

exitForm.addEventListener("submit", evento => {
  evento.preventDefault();

  try {
    const mensaje = registrarSalida(datos, exitPlate.value);

    guardarDatos();
    actualizarPantalla();

    exitForm.reset();
    mostrarMensaje(mensaje, "success");

  } catch (error) {
    mostrarMensaje(
      error instanceof Error ? error.message : "Error al registrar salida.",
      "error"
    );
  }
});

// ============================================
// CREAR / EDITAR ESPACIOS
// ============================================

spaceForm.addEventListener("submit", evento => {
  evento.preventDefault();

  try {
    let mensaje: string;

    if (editSpaceId !== null) {
      mensaje = editarEspacio(datos, editSpaceId, spaceCode.value);
    } else {
      const nuevo = crearEspacio(datos, spaceCode.value);
      mensaje = `Espacio ${nuevo.codigo} creado correctamente.`;
    }

    guardarDatos();
    actualizarPantalla();
    limpiarFormularioEspacio();

    mostrarMensaje(mensaje, "success");

  } catch (error) {
    mostrarMensaje(
      error instanceof Error ? error.message : "Error al guardar el espacio.",
      "error"
    );
  }
});

// ============================================
// BOTONES EDITAR / ELIMINAR
// ============================================

spacesTableBody.addEventListener("click", evento => {
  const objetivo = evento.target as HTMLElement;
  const boton = objetivo.closest("button");

  if (!boton) return;

  const id = Number(boton.dataset.id);

  const espacio = datos.espacios.find(e => e.id === id);

  if (!espacio) return;

  if (boton.classList.contains("edit-space")) {
    iniciarEdicion(espacio);
  }

  if (boton.classList.contains("delete-space")) {
    if (espacio.ocupado) {
      mostrarMensaje("No se puede eliminar un parqueo ocupado.", "error");
      return;
    }

    const confirmar = window.confirm(
      `¿Deseas eliminar el espacio ${espacio.codigo}?`
    );

    if (!confirmar) return;

    try {
      const mensaje = eliminarEspacio(datos, id);

      guardarDatos();
      actualizarPantalla();

      mostrarMensaje(mensaje, "success");

    } catch (error) {
      mostrarMensaje(
        error instanceof Error ? error.message : "Error al eliminar.",
        "error"
      );
    }
  }
});

// ============================================
// CANCELAR EDICIÓN
// ============================================

cancelEditButton.addEventListener("click", limpiarFormularioEspacio);

// ============================================
// BÚSQUEDAS Y FILTROS
// ============================================

parkingSearch.addEventListener("input", renderParking);
parkingFilter.addEventListener("change", renderParking);

historySearch.addEventListener("input", renderHistorial);
historyFilter.addEventListener("change", renderHistorial);

// ============================================
// RESTABLECER DEMOSTRACIÓN
// ============================================

resetButton.addEventListener("click", async () => {
  const confirmar = window.confirm(
    "¿Restablecer todos los datos del parqueo? Esta acción eliminará los registros actuales."
  );

  if (!confirmar) return;

  localStorage.removeItem(STORAGE_KEY);

  await cargarDatos();

  limpiarFormularioEspacio();

  mostrarMensaje("Datos restablecidos correctamente.", "success");
});

// ============================================
// INICIAR SISTEMA
// ============================================

void cargarDatos();
