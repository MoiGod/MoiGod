
export interface Espacio {
  id: number;
  codigo: string;
  ocupado: boolean;
  placa: string | null;
}

export interface Estancia {
  id: number;
  placa: string;
  espacioId: number;
  entrada: string;
  salida: string | null;
  activa: boolean;
  tarifa: number;
}

export interface Movimiento {
  id: number;
  tipo: "entrada" | "salida";
  placa: string;
  espacioCodigo: string;
  fecha: string;
  detalle: string;
  monto: number;
}

export interface DatosParqueo {
  espacios: Espacio[];
  estancias: Estancia[];
  movimientos: Movimiento[];
  recaudacion: number;
}
